import { getTenantAccessToken, fetchTableRecords, TABLE_IDS } from "./feishu"

// 格式化达人数据库
function formatCreators(records: any[]) {
  return records.map((r) => {
    const f = r.fields
    return {
      id: r.record_id,
      tkId: f["tk id"] || f["TK ID"] || "",
      realName: f["达人真实姓名"] || "",
      account: f["达人账号"] || "",
      priority: f["优先级"] || "C",
      shopLink: f["tkshop主页链接"] || "",
      tkLink: f["tk主页链接"] || "",
      store: f["店铺"] || "",
      category: f["类目"] || "",
      language: f["语言"] || "",
      phone: f["电话号码"] || "",
      address: f["收件地址"] || "",
      email: f["邮箱"] || "",
      initialFollowers: f["初次建联粉丝数"] || 0,
      cooperationCount: f["合作次数"] || 0,
      cooperationType: f["合作方式"] || "",
      gmv: f["带货GMV"] || 0,
      commissionSpend: f["佣金支出"] || 0,
      netProfit: f["净收益"] || 0,
      voiceAuth: f["声音授权"] || false,
    }
  })
}

// 格式化寄样登记表
function formatSamples(records: any[]) {
  return records.map((r) => {
    const f = r.fields
    const receiveDate = f["确认收货日期"]
    const publishDate = f["视频发布日期"]
    let daysToPublish = f["收货到发布天数"] || null

    // 自动计算收货到发布天数
    if (!daysToPublish && receiveDate && publishDate) {
      const diff =
        (new Date(publishDate).getTime() - new Date(receiveDate).getTime()) /
        (1000 * 60 * 60 * 24)
      daysToPublish = Math.round(diff)
    }

    return {
      id: r.record_id,
      contactTime: f["对接时间"] || "",
      contactPerson: f["对接人"] || "",
      store: f["店铺"] || "",
      creatorAccount: f["达人账号"] || "",
      creatorPage: f["达人主页"] || "",
      creatorInfo: f["达人情况"] || "",
      sampleName: f["样品名称"] || "",
      sampleSku: f["样品SKU"] || "",
      price: f["售价"] || 0,
      productId: f["商品ID"] || "",
      commission: f["达人佣金"] || "",
      isFree: f["样品是否免费"] || false,
      receiveStatus: f["样品收到情况"] || "",
      receiveDate: receiveDate || "",
      videoPublished: f["视频是否发布"] || false,
      publishDate: publishDate || "",
      daysToPublish,
      hasShopWindow: f["链接是否挂橱窗"] || false,
      videoCount: f["视频总数"] || 0,
      cooperationStatus: f["合作状态"] || "",
      contactInfo: f["联系方式"] || "",
      note: f["备注"] || "",
    }
  })
}

// 格式化内容表现表
function formatContent(records: any[]) {
  return records.map((r) => {
    const f = r.fields
    return {
      id: r.record_id,
      creatorAccount: f["达人账号"] || "",
      videoLink: f["视频链接"] || "",
      product: f["产品"] || "",
      store: f["店铺"] || "",
      publishDate: f["发布日期"] || "",
      views: f["视频播放量"] || 0,
      engagementRate: f["视频互动率"] || 0,
      gpm: f["视频GPM"] || 0,
      gmv: f["视频GMV"] || 0,
      isHit: f["是否爆款"] || false,
      liveCount: f["直播场次"] || 0,
      liveViews: f["直播播放量"] || 0,
      liveGpm: f["直播GPM"] || 0,
      contentType: f["内容类型"] || "",
      boostStatus: f["投流状态"] || "",
      description: f["描述"] || "",
    }
  })
}

// 格式化销售表现表
function formatSales(records: any[]) {
  return records.map((r) => {
    const f = r.fields
    const gmv = f["归因GMV"] || 0
    const sampleCost = f["样品成本"] || 0
    const commission = f["佣金支出"] || 0
    const netProfit = f["净收益"] || gmv - sampleCost - commission

    return {
      id: r.record_id,
      creatorAccount: f["达人账号"] || "",
      product: f["产品"] || "",
      sampleCost,
      commissionRate: f["佣金率"] || 0,
      gmv,
      orderCount: f["成交件数"] || 0,
      avgOrderValue: f["平均客单价"] || 0,
      commissionSpend: commission,
      netProfit,
      roi: sampleCost + commission > 0
        ? Math.round((netProfit / (sampleCost + commission)) * 100)
        : 0,
      cooperationType: f["合作类型"] || "",
      isTargeted: f["定向/公开合作"] || "",
      rating: f["评级"] || "",
      description: f["描述"] || "",
    }
  })
}

// 主函数：拉取所有表数据
export async function syncFromFeishu() {
  const token = await getTenantAccessToken()

  const [creatorRecords, sampleRecords, contentRecords, salesRecords] =
    await Promise.all([
      fetchTableRecords(TABLE_IDS.creators, token),
      fetchTableRecords(TABLE_IDS.samples, token),
      fetchTableRecords(TABLE_IDS.content, token),
      fetchTableRecords(TABLE_IDS.sales, token),
    ])

  return {
    creators: formatCreators(creatorRecords),
    samples: formatSamples(sampleRecords),
    content: formatContent(contentRecords),
    sales: formatSales(salesRecords),
    syncedAt: new Date().toISOString(),
  }
}
